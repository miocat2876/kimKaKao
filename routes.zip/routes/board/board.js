var express = require('express');
var router = express.Router();

var aa = ""

//라우터의 get()함수를 이용해 request URL('/')에 대한 업무처리 로직 정의
var boardList = require('./boardList');

router.get('/', function(req, res, next) {
	
	aa = aa + "aa!";
	
	console.log(aa);

	boardList.run(req, res);
});


router.get('/insert', function(req, res, next) {
	
	aa = aa + "aa!";
	
	console.log(aa);
	
	boardInsert.run(req, res);
});

router.get('/update', function(req, res, next) {
	
	aa = aa + "aa!";
	
	console.log(aa);
	
	boardUpdate.run(req, res);
});

//모듈에 등록해야 web.js에서 app.use 함수를 통해서 사용 가능
module.exports = router;