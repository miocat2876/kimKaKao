
var list = [
			 { num :1
	         ,subject : "a"}
			,{ num :3
		      ,subject : "c"}
			,{ num :2
		      ,subject : "b"}

]


var boardList = {
		
		run : function(req, res){
	        res.send(list + req.requestTime);
	    }
		
}

var boardUpdate = {
		
		run : function(req, res){
	        list.push();
	    }
		
}

var boardInsert = {
		
		run : function(req, res){
	        res.send(list);
	    }
		
}


module.exports = boardList;